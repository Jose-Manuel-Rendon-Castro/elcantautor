import { useParams } from "react-router"
import Header from "../../components/header/Header"
import guitar from "../../images/electricGuitar.jpg"

function InstrumentsPage() {
    
    type instrument = {
    name: string;
    type: string;
    };

    const instruments: instrument[] = [
        {name: "Guitarras acusticas", type: "Guitarras"},
        {name: "Guitarras electricas", type: "Guitarras"},
        {name: "Guitarras electroacusticas", type: "Guitarras"},
        {name: "Accesorios para guitarra", type: "Guitarras"},
        {name: "Bajos electricos", type: "Bajos"},
        {name: "Bajos acusticos", type: "Bajos"},
        {name:"Bajos electroacusticos", type: "Bajos"},
        {name: "Accesorios para Bajo", type: "Bajos"},
        {name: "Baterias", type: "Baterias y percusiones"},
        {name: "Instrumentos de percusion", type: "Baterias y percusiones"},
        {name: "Percusíon latina", type: "Baterias y percusiones"},
        {name: "Bateria acustica", type: "Baterias"},
        {name: "Bateria electrica", type: "Baterias"},
        {name: "Tambores", type: "Baterias"},
        {name: "Tarolas", type: "Baterias"},
        {name: "Platillos", type: "Baterias"},
        {name: "Pedales", type: "Baterias"},
        {name: "Teclados", type: "Teclados y sintentizadores"},
        {name: "Sintetizadores", type: "Teclados y sintentizadores"},
        {name: "Accesorios", type: "Teclados y sintentizadores"},
        {name: "Amplificadores", type: "Equipo de Audio"},
        {name: "Altavoces", type: "Equipo de Audio"},
        {name: "Consolas de audio", type: "Equipo de Audio"}
    ];
    
    const {category, subcategory,subsubcategory} = useParams<{
        category: string;
        subcategory: string;
        subsubcategory: string;
    }>();

    return(
        <>
            <Header/>
            <div id="info-image">
                <img src={guitar} alt="Guitarra electrica"/>
                <div id="info-box">
                    <div id="info">
                    </div>
                </div>
            </div>
        </>
    );

}

export default InstrumentsPage