function Footer() {
    return(
        <footer>
            <p>&copy; {new Date().getFullYear()} El cantautor</p>
        </footer>
    )
}

export default Footer